# Website layer

**Shipping it? Start at `website/HANDOFF.md`.**

The CoreSight marketing website (repo `CoreSight-Systems/coresight-my-website`, read-only here).

- `current/` — the live site exactly as pulled from the repo (2026-10-19). Reference only.
- `Home.html`, `Features.html`, `site.css`, `bg-e.css` (Contours background), `embed.js`, `assets/` — the overhaul (Direction A: forged, refined). No separate pricing page; pricing lives in the Home `#pricing` section.
- Product videos are embedded from `../videos/*.html` via iframes (`embed.js` hides the player chrome). For production, export each video to MP4 and swap the iframes for `<video autoplay muted loop playsinline>`.
- Website colors live in `site.css :root` (separate brand palette from the product's `tokens.css`).
- Book a demo currently opens an email to coresight.systems@gmail.com — swap for a scheduling link.

## Handoff notes (website + videos)
- **Videos are slow in this preview** because each one compiles React/JSX in the browser. Fixed here as far as possible: only the on-screen video loads (one at a time) and it restarts each time it scrolls back in. Production fix: export each video to MP4/WebM (1920×1080), host on the site/CDN, and swap `.vslot` for `<video muted playsinline preload="none" poster>` driven by the same IntersectionObserver in `embed.js` (play + currentTime=0 on enter, pause on leave).
- **Demo form** posts to FormSubmit (`https://formsubmit.co/anthony@coresight.systems`). The first submission triggers a one-time confirmation email to that address — click it to activate. Swap for your own backend/CRM endpoint whenever ready.
- **Pricing**: Lite $299/mo (CRM core), Operations (recommended, quoted by module), Custom (50+ users / extra modules, brass accent). Feature rows carry plan tags so the AI intake, Quoting and Field Ops videos aren't read as part of Lite.
- Videos accept `?embed=1` (hides player chrome, doesn't persist the playhead).
