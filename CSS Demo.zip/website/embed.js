/* embed.js — product videos (../videos/*.html timeline compositions) inside website pages.
   Each .vslot mounts its video only while it is the most-visible slot on screen (≥55%), and
   unmounts when scrolled away — so one plays at a time, and it restarts from 0 every time it
   comes back. Videos load with ?embed=1 (player chrome hidden, playhead not persisted).
   Production: swap each slot for an exported MP4 (<video muted playsinline preload="none">)
   using the same observer to play()/pause()+currentTime=0. */
(function () {
  var slots = [], ratios = new Map(), active = null;
  function mount(s) {
    if (s.querySelector('iframe')) return;
    var f = document.createElement('iframe');
    f.src = s.dataset.src + (s.dataset.src.indexOf('?') < 0 ? '?' : '&') + 'embed=1';
    f.title = s.dataset.title || 'CoreSight product video';
    f.setAttribute('allow', 'autoplay');
    s.appendChild(f); s.classList.add('live');
  }
  function unmount(s) { var f = s.querySelector('iframe'); if (f) f.remove(); s.classList.remove('live'); }
  function pick() {
    var best = null, br = 0.55;
    slots.forEach(function (s) { var r = ratios.get(s) || 0; if (r >= br) { best = s; br = r; } });
    if (best === active) return;
    if (active && (ratios.get(active) || 0) > 0.25 && !best) return;
    if (active) unmount(active);
    active = best; if (best) mount(best);
  }
  function init() {
    slots = [].slice.call(document.querySelectorAll('.vslot'));
    slots.forEach(function (s) {
      var p = document.createElement('div'); p.className = 'vposter';
      p.innerHTML = '<span class="vplay" aria-hidden="true"></span><span class="vlabel">' + (s.dataset.title || '') + '</span>';
      s.appendChild(p);
      s.addEventListener('click', function () { if (active && active !== s) unmount(active); active = s; unmount(s); mount(s); });
    });
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { ratios.set(e.target, e.intersectionRatio); }); pick(); }, { threshold: [0, 0.25, 0.4, 0.55, 0.7, 0.85, 1] });
    slots.forEach(function (s) { io.observe(s); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
