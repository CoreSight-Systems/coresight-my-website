# WEBSITE HANDOFF — coresight-my-website (for Claude Code)

**Start here for the website.** It is separate from the app handoff (`../HANDOFF.md`).

- **Target repo:** `CoreSight-Systems/coresight-my-website`. Today it is a plain static site
  at the repo root with no build step: `index.html`, `marketing.css`, `privacy.html`,
  `terms.html`, `coresight_emblem.png` and `coresight_forged_tile.png`.
- **This folder** (`website/`) is the approved redesign. These pages *are* the shippable
  HTML/CSS. Unlike the app prototype, this is plain static markup with no React, so it can
  be ported almost as-is. The one exception is how the videos are embedded (§4).
- `website/current/` is a copy of what is live today, kept for reference. Don't ship it.

## 1. What changes on the live site

| Live today | Becomes | Source here |
| --- | --- | --- |
| `index.html` (single long page) | **Home** — rewritten copy, new sections | `website/Home.html` |
| *(none)* | **Features** page, new (`/features.html`) | `website/Features.html` |
| `marketing.css` | `site.css` (layout + components) + `bg-e.css` (background) | `website/site.css`, `website/bg-e.css` |
| inline/`mailto:` demo link | **Demo request form** + **Lite signup** + **Request a quote** modals | inside `Home.html` |
| `privacy.html`, `terms.html` | **unchanged** (keep as-is) | `website/current/` |
| images at root | move to `assets/` | `website/assets/` |

**Decisions already made (don't revisit):**
- Visual direction: **"A · Forged, refined"** on the **"Contours"** background. Dark grey
  base, offset ripple rings tinted blue, violet and amber, with a fine grain. The "Your own
  system" section sits on the bare background, with no panel behind it.
- **No separate pricing page.** Pricing lives on Home (`#pricing`). The navbar's
  "Pricing" link points to `Home#pricing`.
- The nav "Contact" link and every "Book a demo" button go to the demo form at `#demo`.
  On Features, that is its own `#demo` section.

### Home (`Home.html`), top to bottom
1. **Hero:** "Run the whole operation in one system." with the lede "…Stop chasing status
   updates. Start operating." Dashboard video below it.
2. **Five apps, three spreadsheets, and a few people who know where everything is.**
3. **Everything we do:**
   - Platform (links to Features)
   - Websites, built & hosted
   - Phone service for your whole company
   - Integrations
   - Migrations
4. **Your own system:** dedicated environment in plain language ("A breach elsewhere can't
   reach you", …).
5. **Built your way:** a role/access table, other things you control, and the
   "0 support tickets" banner.
6. **Pricing:**
   - $0 per seat · Only the modules you use · No contracts required (contracts are
     available on request, with yearly discounts).
   - Three plans:
     - **Lite $299/mo** (green): CRM only, up to 50 users.
     - **Operations** (blue, "Recommended", quoted by module).
     - **Custom** (brass, "Let's talk"): 50+ users, integrations, data migrations.
   - A security line, and an add-ons line (websites, phones, integrations, migrations).
7. **Book a demo** form.

### Features (`Features.html`)
Sections, each a full-screen row with a video:
1. **Front Desk · Core Call**, with a 4-step intake strip.
2. **Nudges**
3. **Quotes**
4. **Field Ops**
5. **Invoicing** (new)
6. **Dashboard**

Plus a **Security** section and the demo form.

Each row has a plan tag: "Operations plan" or "Included in every plan". Invoicing is
tagged **Operations plan** (it is not in Lite).

## 2. Forms — what to wire

All three forms currently post to **FormSubmit** at
`https://formsubmit.co/anthony@coresight.systems`. They include a honeypot field
(`_honey`) and the `_template=table` option.

| Form | Opened from | Email subject (must stay distinct) |
| --- | --- | --- |
| Book a demo | `#demo` section, nav Contact, every "Book a demo" | `CoreSight — DEMO request` |
| Lite signup (name/company/email/phone) | Lite card › "Get Lite" | `CoreSight — LITE plan signup` |
| Request a quote | Operations / Custom › "Request a quote" | `CoreSight — OPERATIONS quote request` · `CoreSight — CUSTOM quote request` · `CoreSight — QUOTE (plan undecided)`, following the Plan select (JS `syncSubj()`) |

**To do:**
- [ ] Keep FormSubmit for launch. Anthony must click the **one-time activation email**
  FormSubmit sends after the first submission.
- [ ] *(Optional, later)* Move to a real endpoint (CRM or serverless function). Keep the same
  field names and the same distinct subjects.
- [ ] Add a thank-you redirect: set the `_next` hidden field to `/thanks.html`, and create a
  simple page in the same style.
- [ ] Keep the honeypot, and add rate limiting or a captcha if spam shows up.

## 3. Assets

- `assets/coresight_emblem.png` and `assets/coresight_forged_tile.png`: move them from the
  repo root.
- The `bg-e.css` grain is an inline SVG data URI, so there's nothing to host for it.
- Fonts are Google Fonts (Chakra Petch and Saira) loaded from `<head>`. Keep that, or
  self-host them.

## 4. Videos — the one real engineering task

In this preview, each video is a live HTML/React composition from `../videos/*.html`,
embedded through `embed.js`. That **can't ship as-is**: it is heavy, compiles in the
browser, and lives outside the website repo.

**Ship it like this:**
1. **Export each video to MP4** at 1920×1080, H.264, about 6–8 Mbps, with a WebM version
   too if you like. Anthony exports these from the design project, one file per video:
   `dashboard.mp4`, `front-desk.mp4`, `nudges.mp4`, `quote.mp4`, `field-ops.mp4` and
   `invoicing.mp4`. Also export a **poster** JPG of the first frame for each.
2. Put them in `assets/video/`, or on a CDN if the files are large.
3. **Replace every `.vslot` element** (`<div class="screen vslot" data-src="../videos/X.html">`)
   with:
   ```html
   <div class="screen vslot"><video muted playsinline preload="none" poster="assets/video/X.jpg">
     <source src="assets/video/X.mp4" type="video/mp4"></video></div>
   ```
4. **Rewrite `embed.js`** to keep the same behaviour, now on `<video>`:
   - Only the **most-visible slot (≥55%) plays**, so just one video plays at a time.
   - Each time a slot becomes the active one, set `currentTime = 0` and call `play()`.
   - When it stops being the active one, call `pause()`.
   - **Clicking** a slot restarts it.
   - The poster overlay (`.vposter`) hides while the video plays.
5. Respect `prefers-reduced-motion`: don't autoplay; show the poster with a play button.

**Videos and where they go:** Home hero → Dashboard. Features → Front Desk, Nudges, Quote,
Field Ops, Invoicing, Dashboard.

## 5. Deploy & housekeeping

- [ ] **Rename:** `Home.html` → `index.html` and `Features.html` → `features.html`. Update
  every internal link: nav, footer, "See every feature", and the `Home.html#pricing`
  references.
- [ ] Footer links → `privacy.html` and `terms.html` at the root, not `current/…`.
- [ ] Add `<meta name="description">`, Open Graph tags (title, description, image = the
  dashboard poster) and a favicon made from the emblem.
- [ ] Add a `sitemap.xml` and `robots.txt`.
- [ ] **Checks:** Lighthouse score above 90 on both pages, and a full-page check at 375px,
  768px, 1280px and 1920px. The layouts already reflow at 900px.
- [ ] **Mobile:** the pages are responsive. Below 900px the nav collapses into a menu button that opens a full-width panel, and grids stack. There is no sideways scroll at 360px. Keep it that way, and test on a real phone.
- [ ] **Accessibility:**
  - The modals are native `<dialog>` elements: confirm focus moves into them and Esc
    closes them.
  - The forms need labels (they already have them).
  - Every video needs a `title` or `aria-label`.
- [ ] Remove the live site's old `marketing.css` once nothing references it.

## 6. Copy & content notes (for accuracy)

- **Invoicing** and the **MONEY / INSIGHTS** areas aren't live in the app yet (see
  `../HANDOFF.md` §4). The Invoicing row on Features is approved to ship.
  - If launch comes **before** the app ships invoicing, either remove that row, or keep it
    and add a "Coming soon" note to its plan tag. **Ask Anthony.**
- **Phone service, websites, integrations and migrations** are custom-priced services.
  The copy says so. Don't add prices.
- The **pricing figures** are final: Lite $299/mo for up to 50 users; Operations and
  Custom are quoted.

## 7. Done when

- The live site shows the new Home and Features pages with the Contours background.
- All three forms deliver email with the correct, distinct subjects.
- Videos play as MP4: one at a time, restarting when scrolled back into view.
- The privacy and terms pages still work.
- No 404s, and every Lighthouse category is above 90.
